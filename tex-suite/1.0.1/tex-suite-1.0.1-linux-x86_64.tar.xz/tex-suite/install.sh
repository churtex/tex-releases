#!/bin/sh
# Install Churtex for the current user (no sudo needed).
# Puts the programs in ~/.local/bin and adds the app menu entry, icon and
# .texvault file type. Remove with: ./install.sh --uninstall
set -e
here=$(cd "$(dirname "$0")" && pwd)
bin="$HOME/.local/bin"
share="${XDG_DATA_HOME:-$HOME/.local/share}"
if [ "$1" = "--uninstall" ]; then
    rm -f "$bin/texsuite" "$bin/tex-suite" "$bin/texsuite.sig" "$bin/tex-suite.sig" "$share/applications/tex-suite.desktop" "$share/mime/packages/tex-suite.xml"
    rm -f "$share"/icons/hicolor/*/apps/tex-suite.png "$share/icons/hicolor/scalable/apps/tex-suite.svg"
    rm -rf "$share/tex-suite/media"
    echo "Churtex removed."
    exit 0
fi
mkdir -p "$bin" "$share/applications" "$share/mime/packages" "$share/icons/hicolor/scalable/apps"
# Earlier names (Urtex Compressor up to 0.11, Churtex MediaVault 0.12, Tex Vault up to
# 0.30): remove those installs, so the menu shows Churtex only.
for old in urtex-compressor churtex-mediavault tex-mediavault tex-media tex-vault; do
    rm -f "$bin/$old" "$share/applications/$old.desktop" "$share/mime/packages/$old.xml"
    rm -f "$share"/icons/hicolor/*/apps/$old.png "$share/icons/hicolor/scalable/apps/$old.svg"
done
rm -f "$bin/urtex-compress" "$bin/mediavault" "$bin/texmedia" "$bin/texvault"
install -m 755 "$here/texsuite" "$here/tex-suite" "$bin/"
# the signatures the programs check at every start (a local build has none)
for s in tex-suite.sig texsuite.sig; do
    [ -f "$here/$s" ] && install -m 644 "$here/$s" "$bin/"
done
# Churtex's own media programs (ffmpeg, ffprobe, the AV1 encoder) and their
# signatures, where Churtex looks for them (0.76.0 shipped none on Linux and
# a computer's own ffmpeg was used). An update runs this same script, so an
# older install gets them with its next update. Put in place whole: a new
# folder beside the old, then swapped, so a stop never leaves half.
if [ -d "$here/media/bin" ]; then
    media="$share/tex-suite/media"
    rm -rf "$media/bin.new"
    mkdir -p "$media/bin.new"
    cp -p "$here"/media/bin/* "$media/bin.new/"
    chmod 755 "$media/bin.new/ffmpeg" "$media/bin.new/ffprobe" "$media/bin.new/SvtAv1EncApp"
    rm -rf "$media/bin.old"
    [ -d "$media/bin" ] && mv "$media/bin" "$media/bin.old"
    mv "$media/bin.new" "$media/bin"
    rm -rf "$media/bin.old"
fi
sed "s|^Exec=tex-suite|Exec=$bin/tex-suite|" "$here/assets/tex-suite.desktop" > "$share/applications/tex-suite.desktop"
install -m 644 "$here/assets/tex-vault-mime.xml" "$share/mime/packages/tex-suite.xml"
install -m 644 "$here/assets/tex-suite.svg" "$share/icons/hicolor/scalable/apps/"
for n in 32 48 64 128 256 512; do
    mkdir -p "$share/icons/hicolor/${n}x${n}/apps"
    install -m 644 "$here/assets/tex-suite-$n.png" "$share/icons/hicolor/${n}x${n}/apps/tex-suite.png"
done
# the desktop caches icons: refresh it so a new or changed icon shows at once
touch "$share/icons/hicolor"
gtk-update-icon-cache -q -t -f "$share/icons/hicolor" 2>/dev/null || true
update-desktop-database -q "$share/applications" 2>/dev/null || true
update-mime-database "$share/mime" 2>/dev/null || true
echo "Installed. Open Churtex from your applications menu."
case ":$PATH:" in *":$bin:"*) ;; *) echo "Note: add $bin to your PATH to use texsuite in a terminal." ;; esac
