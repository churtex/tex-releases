# About Anivo
> The Anivo Bible Reading Plan, in the words of its author, Aniwene Madolomani.
@category start

## Introduction

In 2023, after joining Bethel Chapel International, I was introduced to a certain bible reading plan. That plan is a daily devotional plan created by a famous pastor and has been active and operational for years. Millions of people and thousands of churches around the world utilize it. As I continued to follow it up over the years, I recognized a few problems with it.

## Problems

- It is dependent on that pastor and their church.

- It is an already created devotional meaning churches have to follow the teachings and leaves little room for churches to curate their own devotionals.

- It requires the internet or access to new books every year.

## Solutions

In efforts to address some of the problems listed above, my heart was burdened to create a new way for christians in my community to read the bible and do daily bible devotionals. In the creation of Anivo, here are the things that were important to consider as foundation.

- A bible reading plan that is timeless (If it is sent to a place like China, or other unfriendly territory, it should remain usable even after many years to come)

- A devotional that is not tied to ready-made teachings but allows the reader to study the bible personally from the daily reading.

- A dated Bible Reading and devotional that allows anyone from anywhere in the world to join in any day of the year and be able to be inline with the rest in the plan.

- A bible reading plan that any church can use, FREELY, to curate devotionals, bible studies and prayer sessions without being worried about copyright or attribution for using it.

## The Birth and Progress of Anivo Bible Reading Plan

In 2025, the first version of Anivo BRP. Below is a list of all versions leading up to the current final version and the challenges that previous versions had.

- Version 1: 365 Bible Reading Plan (It was a chronological reading plan that felt very intense and hard to follow)

- Version 2: 730 Bible Reading plan (It was easier to read and follow, but it had more days with Old Testament reading than New Testament which made it lacking for new converts)

- Version 3: 730 Bible Reading Plan [NTX2] (In this version the New Testament would be repeated twice in the plan while the old testament is read once. Which remained with the challenge of having to use Odd/Even years to make it timeless)

- Version 4 (Current): 366 Bible Reading Plan (In this version NT is the main reading with further reading being OT, and February 29 is added to the plan for Leap Years).

The current version has proven to address all challenges that previous versions had.

## Anivo In Your Church

Reading this document, you may be a Pastor, Church leader, Bible study group leader or someone responsible for deciding whether to use Anivo for your congregation or not. Here are a few things you need to know.

- **Anivo Open-Use Policy**: Churches, ministries, organizations, and individuals are free to use, share, and reproduce it without charge.

- **Anivo Is Timeless**: You never have to worry about updating Anivo every year. It is designed to reset itself every year. With a faithful reader, they will finish reading the bible in one year.

- **Faith & Salvation Focus**: Although it is created to help someone read the full bible. The main readings are all from the New Testament, helping the reader solidify their journey with Christ and work out their own salvation.

- **Anivo is YOURS**: Your church is your responsibility. You can use Anivo as a guide to create devotionals that are curated specifically for your congregation while fostering a habit of Daily Bible Reading. You can call it [YOUR CHURCH NAME] BIBLE READING PLAN

## Note From Author

Anivo is prepared by Aniwene Madolomani, a born again Christian with a desire to create, curate and customize Church Solution. Anivo is a project under Churtex Foundation, a personal initiative to create Church Solutions for the end-times and helping communities thrive through the Church.

“I desire to see a world where communities run to the church for solutions.”
