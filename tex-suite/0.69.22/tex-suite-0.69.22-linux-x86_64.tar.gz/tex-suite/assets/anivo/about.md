# About Anivo
> A Bible reading plan for every day of the year: timeless, free for every church, and built to lead you through the whole Bible.
@category start

## The whole Bible, one day at a time
Anivo gives you one reading plan for every day of the year. Read faithfully, it takes you through **the whole Bible in one year**, one manageable portion at a time.

Every day has two readings:

- **Main reading: the New Testament.** From Matthew to Revelation through the year, keeping Christ at the centre of every day.
- **Further reading: the Old Testament.** In the order its events took place, balanced to about 63 verses a day, so no day is too long.

Note: Tex Suite checks the plan against the full King James Bible: in a year, **every one of its 31,102 verses is read exactly once**, none missed and none repeated.

## Read together, from any day
Every reading belongs to a date, not to a starting point. Whoever you are and whenever you begin, you read the same passage as everyone else on Anivo that day. February 29 has a reading of its own, Psalm 23, used only in leap years.

## Built to last
- **Timeless.** The same plan serves every year, for as long as it is used. There is nothing to renew and nothing to buy.
- **Works anywhere.** No internet and no new books are needed: the plan and the Bible are inside Tex Suite, on your device.
- **Scripture first.** Anivo gives the reading, not ready-made teaching. The lessons come from the Bible itself, as you, your pastor or your study group read it.

## For churches and groups
- **Free to use.** Churches, ministries, organisations and individuals may use, share and reproduce Anivo freely, at no cost and without asking.
- **Yours to shape.** Build your own devotionals, Bible studies and prayer times around the daily readings, and call the plan by your church's name if you wish: "[Your church] Bible Reading Plan".
- **One rhythm for everyone.** Because every reading is dated, a whole congregation can read, pray and talk about the same passage on the same day.

## Carefully refined
Anivo reached its present form through four versions. Each one answered a difficulty readers met with the last: too intense, too weighted toward one Testament, or dependent on the year. Today's plan keeps the New Testament as the daily main reading, the Old Testament as further reading, and a reading for February 29, and it begins again by itself every year.

Anivo is a Churtex project, for the Church.
